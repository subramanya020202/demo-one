package awesomo

import "fmt"

func main() {
    fmt.Println("Awesome!")
}
