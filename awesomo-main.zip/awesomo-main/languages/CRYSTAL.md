## A

[**Amber**](https://github.com/amberframework/amber) - a web application framework written in Crystal inspired by Kemal, Rails, Phoenix and other popular application frameworks

## K

[**Kemal**](https://github.com/kemalcr/kemal) - Fast, Effective, Simple web framework for Crystal.

## L

[**Lucky**](https://github.com/luckyframework/lucky) - a web framework that helps you work quickly, catch bugs at compile time, and deliver blazing fast responses.

## M

[**Marten**](https://github.com/martenframework/marten) - A web framework that makes building web applications easy, productive, and fun.